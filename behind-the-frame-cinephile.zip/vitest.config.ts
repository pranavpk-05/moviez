import {defineConfig} from 'vitest/config';
export default defineConfig({test:{include:['tests/**/*.test.{ts,tsx}'],environment:'jsdom',globals:false},esbuild:{jsx:'automatic'}});
